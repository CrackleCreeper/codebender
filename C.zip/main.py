token = "MTM1Nzc1NDU4NDY4ODIzMDUyMw.GCAOzc.oRQEBYDpoYSLiD8PjuPXPsWweCu85tP0qYJwjU"
from Structures.Client import HackniteClient
import discord

client = HackniteClient()
client.run(token)
